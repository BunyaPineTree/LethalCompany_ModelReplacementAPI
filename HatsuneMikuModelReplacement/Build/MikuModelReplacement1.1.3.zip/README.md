# Miku Model Replacement v1.1.3
### Replaces default suit with Hatsune Miku. This is the example mod for ModelReplacementAPI

## Instructions
Place in plugins folder next to boneMapMiku.json and ModelReplacementAPI.dll

For more info see https://github.com/BunyaPineTree/LethalCompany_ModelReplacementAPI

## Known Issues
Cloth physics can be very laggy. Use with caution in large lobbies.


## Changelog
	- V1.1.0
		- Improved bone offsets, now actually only replaces the default suit, some script parameter changes
	- v1.0.0
		- Release